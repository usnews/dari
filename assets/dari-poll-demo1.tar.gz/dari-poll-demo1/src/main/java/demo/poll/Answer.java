package demo.poll;

import com.psddev.dari.db.Record;

public class Answer extends Record {

    private String answer;
    @Indexed Poll poll;

    public String getAnswer() {
        return answer;
    }
    public void setAnswer(String answer) {
        this.answer = answer;
    }
    public Poll getPoll() {
        return poll;
    }
    public void setPoll(Poll poll) {
        this.poll = poll;
    }
}